package com.example.Gestion.de.Ventas.para.Supermercados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDeVentasParaSupermercadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDeVentasParaSupermercadosApplication.class, args);
	}

}
