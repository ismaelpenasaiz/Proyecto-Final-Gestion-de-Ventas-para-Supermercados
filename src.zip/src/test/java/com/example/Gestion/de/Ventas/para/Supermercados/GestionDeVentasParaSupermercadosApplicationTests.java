package com.example.Gestion.de.Ventas.para.Supermercados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeVentasParaSupermercadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
